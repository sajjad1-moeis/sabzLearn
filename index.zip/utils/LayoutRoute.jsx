import React from "react";
import Header from "../src/components/common/Header";
import Footer from "../src/components/common/Footer";

export default function LayoutRoute({element}) {
   if (true) {
      return (
         <>
            <Header />
            {element}
            <Footer />
         </>
      );
   } else {
   }
}
