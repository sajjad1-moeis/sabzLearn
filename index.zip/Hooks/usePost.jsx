import React from "react";

export default function usePost() {
   return <div>usePost</div>;
}
